#include <immintrin.h>

int main() {
    __m256 a = _mm256_set1_ps(0.0f);
    return 0;
}
