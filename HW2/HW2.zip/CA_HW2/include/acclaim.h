#pragma once
#include "acclaim/bone.h"
#include "acclaim/motion.h"
#include "acclaim/posture.h"
#include "acclaim/skeleton.h"
